package cs505finaltemplate.CEP;

public class Event {
    public String event;
    public String zip_code;
    public String count;
}
