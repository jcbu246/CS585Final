package cs505finaltemplate.Topics;

import java.util.List;

public class PatientData {

    public int testing_id;
    public String patient_name;
    public String patient_mrn;
    public int patient_zipcode;
    public int patient_status;
    public List<String> contact_list;
    public List<String> event_list;

    public PatientData() {

    }

}