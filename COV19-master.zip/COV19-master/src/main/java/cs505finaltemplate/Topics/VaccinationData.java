package cs505finaltemplate.Topics;

public class VaccinationData {
    public int vaccination_id;
    public String patient_mrn;
    public String patient_name;

    VaccinationData() {

    }
}
