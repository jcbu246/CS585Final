package cs505finaltemplate.Topics;

import java.util.List;

public class HospitalData {
    public int hospital_id;
    public String patient_mrn;
    public String patient_name;
    public int patient_status;

    public HospitalData() {

    }
}
